/*
 * Copyright (c) 2007 Mockito contributors
 * This program is made available under the terms of the MIT License.
 */

/**
 * Implementations of real method calls.
 */
package org.mockito.internal.invocation.realmethod;
