/*
 * Copyright (c) 2007 Mockito contributors
 * This program is made available under the terms of the MIT License.
 */

/**
 * Mockito is a mock library for java - see {@link org.mockito.Mockito} class for for usage.
 *
 * @see org.mockito.Mockito
 */
package org.mockito;
